# Spiritbound

[![tex-Spiritbound-Icon.png](https://i.postimg.cc/d3ZwzcwZ/tex-Spiritbound-Icon.png)]()

# Skills

[![Screenshot-2024-07-03-184554.png](https://i.postimg.cc/zBG7GdRj/Screenshot-2024-07-03-184554.png)]()

Check out my other mods:

https://thunderstore.io/package/tsuyoikenko/Scout/

https://thunderstore.io/package/tsuyoikenko/Seamstress/

https://thunderstore.io/package/tsuyoikenko/Spy/

https://thunderstore.io/package/tsuyoikenko/Interrogator/

https://thunderstore.io/package/tsuyoikenko/Wanderer/

Contact me on Discord: https://discord.gg/3NaMEsvYeD

# Credits

tsuyoikenko - Everything.

TheTimeSweeper - Incredible new Henry template.

rob - Creator of the glorious Henry template.